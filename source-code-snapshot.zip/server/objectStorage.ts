// Referenced from: blueprint:javascript_object_storage
import { Storage, File } from "@google-cloud/storage";
import { Request, Response } from "express";

const REPLIT_SIDECAR_ENDPOINT = process.env.REPLIT_SIDECAR_ENDPOINT || "http://127.0.0.1:1106";

console.log(`[Object Storage] Sidecar endpoint: ${REPLIT_SIDECAR_ENDPOINT}`);

export const objectStorageClient = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${REPLIT_SIDECAR_ENDPOINT}/token`,
    type: "external_account",
    credential_source: {
      url: `${REPLIT_SIDECAR_ENDPOINT}/credential`,
      format: {
        type: "json",
        subject_token_field_name: "access_token",
      },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

export class ObjectNotFoundError extends Error {
  constructor() {
    super("Object not found");
    this.name = "ObjectNotFoundError";
    Object.setPrototypeOf(this, ObjectNotFoundError.prototype);
  }
}

export class ObjectStorageService {
  constructor() {}

  getPublicObjectSearchPaths(): Array<string> {
    const pathsStr = process.env.PUBLIC_OBJECT_SEARCH_PATHS || "";
    const paths = Array.from(
      new Set(
        pathsStr
          .split(",")
          .map((path) => path.trim())
          .filter((path) => path.length > 0)
      )
    );
    if (paths.length === 0) {
      throw new Error(
        "PUBLIC_OBJECT_SEARCH_PATHS not set. Create a bucket in 'Object Storage' " +
          "tool and set PUBLIC_OBJECT_SEARCH_PATHS env var (comma-separated paths)."
      );
    }
    return paths;
  }

  async searchPublicObject(filePath: string): Promise<File | null> {
    for (const searchPath of this.getPublicObjectSearchPaths()) {
      const fullPath = `${searchPath}/${filePath}`;
      const { bucketName, objectName } = parseObjectPath(fullPath);
      const bucket = objectStorageClient.bucket(bucketName);
      const file = bucket.file(objectName);

      const [exists] = await file.exists();
      if (exists) {
        return file;
      }
    }

    return null;
  }

  async getSignedUrl(file: File, expiresInMinutes: number = 60): Promise<string> {
    const [url] = await file.getSignedUrl({
      version: 'v4',
      action: 'read',
      expires: Date.now() + expiresInMinutes * 60 * 1000,
    });
    return url;
  }

  async downloadObject(file: File, req: Request, res: Response, cacheTtlSec: number = 3600) {
    try {
      console.log(`[Object Storage] Starting downloadObject for: ${file.name}`);
      console.log(`[Object Storage] Getting metadata...`);
      const [metadata] = await file.getMetadata();
      console.log(`[Object Storage] Metadata received:`, metadata.size);
      const fileSize = parseInt(metadata.size as string);
      const range = req.headers.range;
      console.log(`[Object Storage] File size: ${fileSize}, Range: ${range}`);
      
      // For videos, download only the requested range to buffer
      const fileName = file.name.toLowerCase();
      const isVideo = fileName.endsWith('.mp4') || fileName.endsWith('.webm') || fileName.endsWith('.ogg');
      
      if (isVideo) {
        console.log(`[Object Storage] Video file detected, using range-buffered delivery`);
        
        if (range) {
          const parts = range.replace(/bytes=/, "").split("-");
          const start = parseInt(parts[0], 10);
          let end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
          
          // Safety limit: cap chunk size at 10MB to avoid deployment timeouts while enabling smoother playback
          const MAX_CHUNK_SIZE = 10 * 1024 * 1024; // 10MB
          const requestedChunkSize = (end - start) + 1;
          if (requestedChunkSize > MAX_CHUNK_SIZE) {
            end = start + MAX_CHUNK_SIZE - 1;
            console.log(`[Object Storage] Requested chunk ${requestedChunkSize} bytes exceeds limit, capping to ${MAX_CHUNK_SIZE} bytes`);
          }
          
          const chunkSize = (end - start) + 1;
          
          console.log(`[Object Storage] Downloading range ${start}-${end} (${chunkSize} bytes) to buffer...`);
          const [buffer] = await file.download({ start, end });
          console.log(`[Object Storage] Range buffer downloaded, size: ${buffer.length} bytes`);
          
          res.status(206);
          res.set({
            "Content-Type": metadata.contentType || "video/mp4",
            "Accept-Ranges": "bytes",
            "Cache-Control": `public, max-age=${cacheTtlSec}`,
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
            "Access-Control-Allow-Headers": "Range, Content-Type",
            "Access-Control-Expose-Headers": "Content-Length, Content-Range, Accept-Ranges",
            "Content-Length": buffer.length.toString(),
            "Content-Range": `bytes ${start}-${end}/${fileSize}`,
          });
          return res.send(buffer);
        } else {
          // For non-range requests, send first 10MB chunk with range support
          console.log(`[Object Storage] Non-range video request, downloading first chunk...`);
          const chunkSize = Math.min(10 * 1024 * 1024, fileSize); // 10MB or file size
          const [buffer] = await file.download({ start: 0, end: chunkSize });
          console.log(`[Object Storage] Initial chunk downloaded, size: ${buffer.length} bytes`);
          
          res.status(200);
          res.set({
            "Content-Type": metadata.contentType || "video/mp4",
            "Accept-Ranges": "bytes",
            "Cache-Control": `public, max-age=${cacheTtlSec}`,
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
            "Access-Control-Allow-Headers": "Range, Content-Type",
            "Access-Control-Expose-Headers": "Content-Length, Content-Range, Accept-Ranges",
            "Content-Length": fileSize.toString(),
          });
          return res.send(buffer);
        }
      }

      // Determine content type for non-video files
      let contentType = metadata.contentType || "application/octet-stream";
      if (fileName.endsWith('.mp4')) {
        contentType = "video/mp4";
      } else if (fileName.endsWith('.webm')) {
        contentType = "video/webm";
      } else if (fileName.endsWith('.ogg')) {
        contentType = "video/ogg";
      }

      console.log(`[Object Storage] Serving file: ${file.name}, Content-Type: ${contentType}, Size: ${fileSize}`);

      // Common headers for both range and non-range requests
      const commonHeaders = {
        "Content-Type": contentType,
        "Accept-Ranges": "bytes",
        "Cache-Control": `public, max-age=${cacheTtlSec}`,
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
        "Access-Control-Allow-Headers": "Range, Content-Type",
        "Access-Control-Expose-Headers": "Content-Length, Content-Range, Accept-Ranges",
      };

      if (range) {
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
        const chunkSize = (end - start) + 1;

        console.log(`[Object Storage] Range request: ${start}-${end}/${fileSize} (chunk: ${chunkSize} bytes)`);

        res.status(206);
        res.set({
          ...commonHeaders,
          "Content-Length": chunkSize.toString(),
          "Content-Range": `bytes ${start}-${end}/${fileSize}`,
        });

        const stream = file.createReadStream({ start, end });
        
        // Set a timeout for the response
        req.socket.setTimeout(300000); // 5 minutes
        
        stream.on("error", (err: Error) => {
          console.error("[Object Storage] Stream error:", err);
          if (!res.headersSent) {
            res.status(500).json({ error: "Error streaming file" });
          }
        });
        
        stream.on("end", () => {
          console.log("[Object Storage] Stream completed successfully");
        });
        
        stream.pipe(res);
      } else {
        console.log(`[Object Storage] Full file request: ${fileSize} bytes`);

        res.status(200);
        res.set({
          ...commonHeaders,
          "Content-Length": fileSize.toString(),
        });

        const stream = file.createReadStream();
        
        // Set a timeout for the response
        req.socket.setTimeout(300000); // 5 minutes
        
        stream.on("error", (err: Error) => {
          console.error("[Object Storage] Stream error:", err);
          if (!res.headersSent) {
            res.status(500).json({ error: "Error streaming file" });
          }
        });
        
        stream.on("end", () => {
          console.log("[Object Storage] Stream completed successfully");
        });
        
        stream.pipe(res);
      }
    } catch (error) {
      console.error("[Object Storage] FATAL ERROR downloading file:", error);
      console.error("[Object Storage] Error stack:", error instanceof Error ? error.stack : 'No stack');
      console.error("[Object Storage] Error name:", error instanceof Error ? error.name : 'Unknown');
      console.error("[Object Storage] Error message:", error instanceof Error ? error.message : String(error));
      if (!res.headersSent) {
        res.status(500).json({ 
          error: "Error downloading file",
          message: error instanceof Error ? error.message : String(error)
        });
      }
    }
  }

}

function parseObjectPath(path: string): {
  bucketName: string;
  objectName: string;
} {
  if (!path.startsWith("/")) {
    path = `/${path}`;
  }
  const pathParts = path.split("/");
  if (pathParts.length < 3) {
    throw new Error("Invalid path: must contain at least a bucket name");
  }

  const bucketName = pathParts[1];
  const objectName = pathParts.slice(2).join("/");

  return {
    bucketName,
    objectName,
  };
}
