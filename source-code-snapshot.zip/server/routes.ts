import type { Express } from "express";
import { Router } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ObjectStorageService } from "./objectStorage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create dedicated routers for API and public objects
  const apiRouter = Router();
  const publicObjectsRouter = Router();

  // Mount routers BEFORE any catch-all routes
  app.use("/api", apiRouter);
  app.use("/public-objects", publicObjectsRouter);

  // Test Object Storage connectivity and get public URL
  apiRouter.get("/test-storage", async (req, res) => {
    try {
      console.log('[Storage Test] Starting test...');
      const objectStorageService = new ObjectStorageService();
      console.log('[Storage Test] Service created');
      
      const file = await objectStorageService.searchPublicObject('videos/video1.mp4');
      console.log('[Storage Test] Search result:', file ? 'FOUND' : 'NOT FOUND');
      
      if (!file) {
        return res.json({ 
          success: false, 
          error: 'File not found',
          paths: process.env.PUBLIC_OBJECT_SEARCH_PATHS 
        });
      }
      
      const [metadata] = await file.getMetadata();
      console.log('[Storage Test] Metadata retrieved');
      
      // Try to get public URL
      const bucket = file.bucket;
      const publicUrl = `https://storage.googleapis.com/${bucket.name}/${file.name}`;
      
      // Try to make file public
      try {
        await file.makePublic();
        console.log('[Storage Test] File made public');
      } catch (publicError) {
        console.log('[Storage Test] Could not make public:', publicError instanceof Error ? publicError.message : String(publicError));
      }
      
      res.json({ 
        success: true,
        fileName: file.name,
        size: metadata.size,
        contentType: metadata.contentType,
        bucketName: bucket.name,
        publicUrl: publicUrl,
        metadata: metadata.metadata
      });
    } catch (error) {
      console.error('[Storage Test] ERROR:', error);
      res.status(500).json({ 
        success: false, 
        error: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined
      });
    }
  });

  // Debug endpoint to verify deployment version and Object Storage connectivity
  apiRouter.get("/debug/version", async (req, res) => {
    const versionInfo: any = {
      timestamp: new Date().toISOString(),
      deploymentVersion: "v4.7-10MB-CHUNKS",
      environment: process.env.NODE_ENV || 'unknown',
      hasOptionsHandler: true,
      publicObjectSearchPaths: process.env.PUBLIC_OBJECT_SEARCH_PATHS || 'NOT SET',
      privateObjectDir: process.env.PRIVATE_OBJECT_DIR ? 'SET' : 'NOT SET',
      bucketId: process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID ? 'SET' : 'NOT SET',
      sidecarEndpoint: process.env.REPLIT_SIDECAR_ENDPOINT || 'NOT SET',
    };
    
    // Test Object Storage connectivity
    try {
      const objectStorageService = new ObjectStorageService();
      const file = await objectStorageService.searchPublicObject('videos/video1.mp4');
      versionInfo.objectStorageTest = file ? 'CONNECTED' : 'FILE_NOT_FOUND';
    } catch (error) {
      versionInfo.objectStorageTest = `ERROR: ${error instanceof Error ? error.message : String(error)}`;
    }
    
    console.log('[Debug] Version check:', versionInfo);
    res.json(versionInfo);
  });

  // Referenced from: blueprint:javascript_object_storage
  // Handle CORS preflight requests for video streaming
  publicObjectsRouter.options("/:filePath(*)", (req, res) => {
    console.log(`[Object Storage] OPTIONS preflight for: ${req.params.filePath}`);
    res.set({
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
      "Access-Control-Allow-Headers": "Range, Content-Type",
      "Access-Control-Max-Age": "86400", // 24 hours
    });
    res.status(204).send();
  });

  // Get signed URL for direct download from GCS (bypasses our server for better compatibility)
  apiRouter.get("/video-url/:filePath(*)", async (req, res) => {
    const filePath = req.params.filePath;
    console.log(`[Object Storage] Signed URL request for: ${filePath}`);
    
    const objectStorageService = new ObjectStorageService();
    try {
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        console.error(`[Object Storage] File not found: ${filePath}`);
        return res.status(404).json({ error: "File not found" });
      }
      const signedUrl = await objectStorageService.getSignedUrl(file, 120); // 2 hour expiry
      console.log(`[Object Storage] Generated signed URL for: ${filePath}`);
      res.json({ url: signedUrl });
    } catch (error) {
      console.error("[Object Storage] Error:", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  // This endpoint is used to serve public assets from Object Storage.
  // Videos are buffered (downloaded fully from GCS, then sent) to avoid streaming issues
  publicObjectsRouter.get("/:filePath(*)", async (req, res) => {
    const filePath = req.params.filePath;
    console.log(`[Object Storage] Request for: ${filePath}`);
    console.log(`[Object Storage] Range header: ${req.headers.range || 'none'}`);
    console.log(`[Object Storage] PUBLIC_OBJECT_SEARCH_PATHS: ${process.env.PUBLIC_OBJECT_SEARCH_PATHS || 'NOT SET'}`);
    
    const objectStorageService = new ObjectStorageService();
    try {
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        console.error(`[Object Storage] File not found: ${filePath}`);
        return res.status(404).json({ error: "File not found" });
      }
      
      console.log(`[Object Storage] File found, processing: ${filePath}`);
      await objectStorageService.downloadObject(file, req, res);
    } catch (error) {
      console.error("[Object Storage] Error:", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
