import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { GlitchText } from "@/components/glitch-text";
import { useAudio } from "@/hooks/useAudio";
import audioFile from "@assets/Invasion of All Worlds (Remix).mp3";

export default function Auth() {
  const [, setLocation] = useLocation();
  const [loadingStep, setLoadingStep] = useState(0);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const { play, isLoading: audioLoading } = useAudio(audioFile, {
    loop: true,
    volume: 0.4,
    autoplay: false
  });

  const loadingSteps = [
    "INITIALIZING NEURAL LINK...",
    "AUTHORIZING ACCESS...",
    "VERIFYING CLEARANCE LEVEL...",
    "ESTABLISHING SECURE CONNECTION...",
    "TEMPORAL COORDINATES LOCKED...",
    "ACCESS GRANTED"
  ];

  useEffect(() => {
    const stepInterval = setInterval(() => {
      setLoadingStep((prev) => {
        if (prev < loadingSteps.length - 1) {
          return prev + 1;
        } else {
          clearInterval(stepInterval);
          return prev;
        }
      });
    }, 800);

    return () => clearInterval(stepInterval);
  }, []);

  const handleEnterSite = async () => {
    // Enable audio context on user interaction for iOS/Safari compatibility
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      if (audioContext.state === 'suspended') {
        await audioContext.resume();
      }
      setAudioEnabled(true);
    } catch (error) {
      console.warn('Audio context setup failed:', error);
    }
    
    // Navigate to main page where audio will start
    setLocation("/main");
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-void">
      {/* Static Background Pattern */}
      <div className="fixed inset-0 static-bg"></div>
      
      {/* Scanlines Effect */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="w-full h-full opacity-20" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 255, 65, 0.1) 2px, rgba(0, 255, 65, 0.1) 4px)',
        }}></div>
      </div>

      {/* Main Authorization Interface */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4">
        <div className="text-center max-w-md mx-auto">
          
          {/* Syndicate Logo/Symbol */}
          <div className="mb-8">
            <div className="w-24 h-24 mx-auto border-2 border-eerie rounded-full flex items-center justify-center mb-4 eerie-glow">
              <div className="w-12 h-12 border-2 border-eerie rounded-full relative">
                <div className="absolute inset-2 border border-eerie rounded-full"></div>
                <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-eerie rounded-full transform -translate-x-1/2 -translate-y-1/2"></div>
              </div>
            </div>
          </div>

          {/* Title */}
          <h1 className="text-2xl md:text-3xl font-tech font-black text-eerie mb-2">
            <GlitchText dataText="SYNDICATE NETWORK">SYNDICATE NETWORK</GlitchText>
          </h1>
          
          <p className="text-gray-400 text-sm font-mono tracking-widest mb-8">
            SECURE TEMPORAL ACCESS PROTOCOL
          </p>

          {/* Loading Animation */}
          <div className="bg-shadow border border-eerie-dark rounded-lg p-6 mb-8 relative overflow-hidden">
            <div className="scanline"></div>
            <div className="relative z-10">
              <div className="mb-4">
                <div className="w-full bg-void border border-eerie-dark rounded-full h-3 mb-3">
                  <div 
                    className="bg-gradient-to-r from-eerie to-blood h-full rounded-full transition-all duration-800 ease-out"
                    style={{
                      width: `${((loadingStep + 1) / loadingSteps.length) * 100}%`
                    }}
                  ></div>
                </div>
                
                <p className="text-eerie text-sm font-tech tracking-wide">
                  {loadingSteps[loadingStep]}
                </p>
              </div>
              
              <div className="text-xs text-gray-500 font-mono">
                STATUS: {loadingStep === loadingSteps.length - 1 ? 'READY' : 'PROCESSING'} // 
                CLEARANCE: OMEGA-7 // 
                AUDIO: {audioEnabled ? 'ENABLED' : 'PENDING'}
              </div>
            </div>
          </div>

          {/* Enter Button */}
          {loadingStep === loadingSteps.length - 1 && (
            <button 
              className="bg-blood hover:bg-blood-light border border-blood-light px-8 py-3 rounded-lg font-tech font-bold tracking-wider transition-all duration-300 hover:shadow-lg hover:shadow-blood/50 glitch"
              onClick={handleEnterSite}
              data-testid="button-enter-site"
            >
              ENTER TEMPORAL NEXUS
            </button>
          )}

          {/* Warning */}
          <div className="mt-8 text-xs text-gray-500 font-mono max-w-sm mx-auto">
            <p className="text-blood">[ UNAUTHORIZED ACCESS IS PROHIBITED ]</p>
            <p>This system monitors all activity. Proceed only with proper authorization.</p>
          </div>
        </div>
      </div>
    </div>
  );
}