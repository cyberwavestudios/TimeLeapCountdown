import { useEffect } from "react";
import { useLocation } from "wouter";
import continuumBundle from "@assets/CONTINUUM_BUNDLE_1774060583098.png";

export default function Continuum() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen relative overflow-x-hidden bg-void text-white">

      {/* Deep blood background */}
      <div className="fixed inset-0" style={{
        background: 'radial-gradient(ellipse at 50% 0%, rgba(120, 0, 0, 0.25) 0%, transparent 60%), radial-gradient(ellipse at 80% 80%, rgba(80, 0, 0, 0.15) 0%, transparent 50%), #070005'
      }} />

      {/* Scanlines */}
      <div className="fixed inset-0 pointer-events-none opacity-15" style={{
        backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(180, 0, 0, 0.07) 3px, rgba(180, 0, 0, 0.07) 4px)',
      }} />

      {/* Blood-red grid */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.04]" style={{
        backgroundImage: 'linear-gradient(rgba(180,0,0,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(180,0,0,0.6) 1px, transparent 1px)',
        backgroundSize: '60px 60px'
      }} />

      {/* Vignette edges */}
      <div className="fixed inset-0 pointer-events-none" style={{
        background: 'radial-gradient(ellipse at center, transparent 50%, rgba(0,0,0,0.7) 100%)'
      }} />

      {/* Back button */}
      <button
        onClick={() => setLocation('/main')}
        className="fixed top-6 left-6 z-50 border border-red-900 hover:border-red-600 text-red-500 hover:text-red-300 px-4 py-2 rounded font-mono text-sm tracking-widest transition-all duration-300 hover:bg-red-950/40"
      >
        ← RETURN
      </button>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center px-6 pt-24 pb-20">

        {/* Top classified stamp */}
        <div className="border border-red-800/60 px-6 py-1 mb-10 rounded-sm">
          <span className="text-red-700 font-mono text-xs tracking-[0.5em] font-bold">
            SYNDICATE // AUTHORIZED TRANSMISSION
          </span>
        </div>

        {/* Title */}
        <h1 className="text-center font-black mb-1" style={{
          fontFamily: "'Orbitron', sans-serif",
          fontSize: 'clamp(2.8rem, 8vw, 6rem)',
          letterSpacing: '0.06em',
          color: '#fff',
          textShadow: '0 0 60px rgba(180,0,0,0.8), 0 0 120px rgba(120,0,0,0.4)',
        }}>
          CONTINUUM
        </h1>

        <h2 className="text-center mb-2 font-mono tracking-[0.35em] text-red-500 text-sm md:text-base">
          THE INFINITY SET
        </h2>

        <p className="text-red-900/80 font-mono text-xs tracking-[0.3em] mb-10 text-center">
          CLASSIFIED ORIGIN ARCHIVE — CLEARANCE LEVEL: OMEGA
        </p>

        {/* Blood divider */}
        <div className="w-64 h-px mb-12" style={{
          background: 'linear-gradient(90deg, transparent, rgba(180,0,0,0.9), transparent)'
        }} />

        {/* Product image */}
        <div className="relative mb-14 group w-full max-w-lg">
          <div className="absolute -inset-6 rounded-2xl opacity-40 group-hover:opacity-70 transition-opacity duration-700 blur-3xl" style={{
            background: 'radial-gradient(ellipse, rgba(160,0,0,0.7), transparent 70%)'
          }} />
          <div className="absolute inset-0 rounded-xl opacity-20 group-hover:opacity-40 transition-opacity duration-500" style={{
            boxShadow: 'inset 0 0 40px rgba(180,0,0,0.5)'
          }} />
          <img
            src={continuumBundle}
            alt="Continuum: Infinity Set — concept album, graphic novel, and interactive app"
            className="relative rounded-xl shadow-2xl w-full transition-transform duration-700 group-hover:scale-[1.02]"
            style={{ filter: 'drop-shadow(0 0 40px rgba(160,0,0,0.5)) brightness(0.95)' }}
          />
        </div>

        {/* Tagline */}
        <p className="text-center text-white font-mono text-xl md:text-2xl mb-5 max-w-2xl leading-relaxed italic" style={{
          textShadow: '0 0 30px rgba(180,0,0,0.6)'
        }}>
          "We Never Met, But I Remember You"
        </p>

        {/* Pull quote */}
        <p className="text-center text-red-400/70 font-mono text-sm mb-6 max-w-xl leading-relaxed tracking-wide">
          Before the Caesura Event. Before the war.<br />
          Before Cyberwave dared to resist.
        </p>

        <p className="text-center text-white/40 text-sm font-mono max-w-xl leading-loose mb-14 px-4">
          The <span className="text-red-400 font-bold">Continuum: Infinity Set</span> is the origin of everything —
          a concept album, prequel graphic novel, and interactive app ecosystem bundled as a single immersive descent
          into the world of Cyberwave and their sworn enemy, Syndicate.
          Learn who fired the first shot. Learn why the war will never end.
        </p>

        {/* What's included cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-16 w-full max-w-2xl">
          {[
            { icon: '💿', label: 'CONCEPT ALBUM', sub: 'Original score & narrative' },
            { icon: '📖', label: 'GRAPHIC NOVEL', sub: 'Prequel origin story' },
            { icon: '∞', label: 'INTERACTIVE APP', sub: 'Immersive app ecosystem' },
          ].map(({ icon, label, sub }) => (
            <div key={label} className="border border-red-900/60 hover:border-red-700 bg-red-950/10 hover:bg-red-950/25 rounded-lg p-5 text-center transition-all duration-300 group">
              <div className="text-2xl mb-3 group-hover:scale-110 transition-transform duration-300">{icon}</div>
              <div className="text-red-400 font-mono text-xs tracking-widest font-bold mb-1">{label}</div>
              <div className="text-white/30 font-mono text-xs">{sub}</div>
            </div>
          ))}
        </div>

        {/* Warning line */}
        <p className="text-red-900 font-mono text-xs tracking-widest mb-8 text-center uppercase">
          ⚠ &nbsp; What you learn here cannot be unlearned &nbsp; ⚠
        </p>

        {/* CTA Button */}
        <a
          href="https://digitalcomic.cyberwavestudios.com"
          target="_blank"
          rel="noopener noreferrer"
          className="relative group inline-block mb-4"
        >
          <div className="absolute -inset-1 rounded-lg opacity-70 group-hover:opacity-100 transition-opacity duration-300 blur-md" style={{
            background: 'linear-gradient(135deg, rgba(180,0,0,0.9), rgba(100,0,0,0.9))'
          }} />
          <div className="relative px-14 py-4 rounded-lg font-black tracking-widest text-white transition-all duration-300 group-hover:scale-105"
            style={{
              fontFamily: "'Orbitron', sans-serif",
              fontSize: '0.85rem',
              background: 'linear-gradient(135deg, #8b0000, #4a0000)',
              boxShadow: '0 0 40px rgba(180,0,0,0.5)',
              letterSpacing: '0.12em'
            }}
          >
            ENTER THE CONTINUUM →
          </div>
        </a>

        <p className="text-white/20 font-mono text-xs tracking-widest text-center">
          PREVIEW SAMPLER · LEADS TO FULL ORDER PAGE
        </p>

        {/* Bottom divider */}
        <div className="w-48 h-px mt-16 mb-6" style={{
          background: 'linear-gradient(90deg, transparent, rgba(180,0,0,0.5), transparent)'
        }} />

        <div className="text-red-950 font-mono text-xs tracking-widest text-center">
          SYNDICATE STUDIOS // ALL TIMELINES RESERVED
        </div>
      </div>
    </div>
  );
}
