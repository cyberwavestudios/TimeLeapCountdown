import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { GlitchText } from "@/components/glitch-text";
import { useAudio } from "@/hooks/useAudio";
import classifiedAudio from "@assets/Cymatics.mp3";

export default function Classified() {
  const [, setLocation] = useLocation();
  const [isVisible, setIsVisible] = useState(false);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [audioStarted, setAudioStarted] = useState(false);
  const { play, isLoading, audioRef } = useAudio(classifiedAudio, {
    loop: false,
    volume: 0.6,
    autoplay: false
  });

  // Fade in effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  // Handle authorization and audio playback
  const handleAuthorize = async () => {
    setIsAuthorized(true);
    
    // Wait a moment for the overlay to fade
    setTimeout(async () => {
      if (audioRef.current && !audioStarted) {
        try {
          // Force play even if loading state says it's not ready
          await audioRef.current.play();
          setAudioStarted(true);
        } catch (error) {
          console.error('Audio playback failed:', error);
          // Try alternative play method
          try {
            await play();
            setAudioStarted(true);
          } catch (retryError) {
            console.error('Audio retry failed:', retryError);
          }
        }
      }
    }, 500);
  };

  // Set up redirect on audio completion
  useEffect(() => {
    if (audioStarted && audioRef.current) {
      const audio = audioRef.current;
      const handleEnded = () => {
        // Brief pause before redirect to let the abrupt ending sink in
        setTimeout(() => {
          setLocation('/main');
        }, 1000);
      };
      
      audio.addEventListener('ended', handleEnded);
      
      return () => {
        audio.removeEventListener('ended', handleEnded);
      };
    }
  }, [audioStarted, audioRef, setLocation]);

  return (
    <div className="min-h-screen relative overflow-hidden bg-void">
      {/* Authorization Overlay */}
      {!isAuthorized && (
        <div className="fixed inset-0 z-50 bg-void flex items-center justify-center transition-opacity duration-500">
          <div className="text-center px-4">
            {/* Warning Header */}
            <div className="mb-8">
              <div className="text-blood text-2xl md:text-4xl font-tech font-black mb-4 glitch" data-text="⚠ SECURITY CLEARANCE REQUIRED ⚠">
                ⚠ SECURITY CLEARANCE REQUIRED ⚠
              </div>
              <div className="text-gray-400 text-sm font-mono mb-2">
                CLASSIFIED TRANSMISSION DETECTED
              </div>
              <div className="text-eerie text-xs font-mono">
                LEVEL: OMEGA-7 // ENCRYPTION: QUANTUM // STATUS: STANDBY
              </div>
            </div>

            {/* Authorization Button */}
            <button
              onClick={handleAuthorize}
              className="bg-blood hover:bg-blood-light border-2 border-blood-light px-12 py-4 rounded-lg font-tech font-black text-lg md:text-xl tracking-widest transition-all duration-300 hover:shadow-lg hover:shadow-blood/50 glitch"
              data-testid="button-authorize-transmission"
            >
              🔓 AUTHORIZE TRANSMISSION
            </button>

            {/* Warning Text */}
            <div className="mt-8 text-xs text-gray-500 font-mono max-w-md mx-auto space-y-1">
              <p className="text-blood">[ UNAUTHORIZED ACCESS IS A CAPITAL OFFENSE ]</p>
              <p>Click to decrypt and authorize audio transmission.</p>
              <p className="text-eerie">This action will be logged and monitored.</p>
            </div>

            {/* Scanline Effect */}
            <div className="fixed inset-0 pointer-events-none scanline"></div>
          </div>
        </div>
      )}

      {/* Static Background Pattern */}
      <div className="fixed inset-0 static-bg"></div>
      
      {/* Heavy Scanlines Effect for Transmission Feel */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="w-full h-full opacity-30" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 1px, rgba(255, 0, 0, 0.1) 1px, rgba(255, 0, 0, 0.1) 3px)',
        }}></div>
      </div>

      {/* Data Stream Background */}
      <div className="fixed inset-0 pointer-events-none opacity-20 overflow-hidden">
        <div className="absolute inset-0 font-mono text-xs text-green-500 leading-none">
          {Array.from({ length: 50 }, (_, i) => (
            <div key={i} className="whitespace-nowrap animate-pulse" style={{
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}>
              {Array.from({ length: 120 }, () => Math.random() > 0.7 ? '1' : '0').join('')}
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className={`relative z-10 min-h-screen flex flex-col items-center justify-center px-4 transition-all duration-1000 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}>
        
        {/* Classification Header */}
        <div className="text-center mb-8">
          <div className="text-blood text-sm font-tech font-bold tracking-widest mb-2">
            ⚠ CLASSIFIED TRANSMISSION ⚠
          </div>
          <div className="text-gray-400 text-xs font-mono">
            CLEARANCE LEVEL: OMEGA-7 // ENCRYPTION: QUANTUM // STATUS: LIVE
          </div>
        </div>

        {/* Syndicate Logo */}
        <div className="mb-12 relative">
          {/* Glowing backdrop effect */}
          <div className="absolute inset-0 bg-blood opacity-20 blur-xl scale-110 rounded-full"></div>
          
          {/* Main logo container */}
          <div className="relative w-64 h-64 md:w-80 md:h-80 flex items-center justify-center">
            {/* Syndicate Logo SVG based on the reference images */}
            <svg 
              width="100%" 
              height="100%" 
              viewBox="0 0 400 400" 
              className="text-blood drop-shadow-2xl"
              data-testid="syndicate-logo"
            >
              {/* Outer diamond shape */}
              <path 
                d="M200 50 L350 200 L200 350 L50 200 Z" 
                fill="currentColor" 
                className="animate-pulse"
                style={{ animationDuration: '3s' }}
              />
              
              {/* Inner cut-out diamond */}
              <path 
                d="M200 100 L300 200 L200 300 L100 200 Z" 
                fill="var(--void)" 
              />
              
              {/* Center circle */}
              <circle 
                cx="200" 
                cy="200" 
                r="40" 
                fill="currentColor"
                className="animate-pulse"
                style={{ animationDuration: '2s', animationDelay: '0.5s' }}
              />
              
              {/* Additional detail lines for the logo complexity */}
              <path 
                d="M200 120 L280 200 L200 280 L120 200 Z" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2"
                className="opacity-60"
              />
            </svg>
          </div>
          
          {/* Pulsing ring effect */}
          <div className="absolute inset-0 border-2 border-blood rounded-full opacity-30 animate-ping" style={{
            animationDuration: '4s'
          }}></div>
        </div>

        {/* Message Display */}
        <div className="text-center max-w-2xl mx-auto">
          <h1 className="text-2xl md:text-4xl font-tech font-black text-blood mb-6">
            <GlitchText dataText="SYNDICATE NETWORK">SYNDICATE NETWORK</GlitchText>
          </h1>
          
          <div className="bg-shadow border border-blood-dark rounded-lg p-6 mb-6 relative overflow-hidden">
            <div className="scanline"></div>
            <div className="relative z-10">
              <h3 className="text-eerie text-lg md:text-xl font-tech font-bold mb-3 tracking-wide">
                📡 INCOMING TRANSMISSION
              </h3>
              <p className="text-gray-300 text-sm md:text-base leading-relaxed mb-4">
                PRIORITY ALPHA // ORIGIN: SYNDICATE COMMAND // RECIPIENT: ALL STATIONS
              </p>
              <p className="text-blood-light text-xs font-mono tracking-widest">
                DECRYPTION IN PROGRESS... STAND BY FOR MESSAGE...
              </p>
            </div>
          </div>

          {/* Warning Text */}
          <div className="text-xs text-gray-500 font-mono max-w-md mx-auto space-y-1">
            <p className="text-blood">[ THIS IS A RESTRICTED COMMUNICATION ]</p>
            <p>Unauthorized access to this transmission is a capital offense.</p>
            <p>Audio feed will terminate automatically upon completion.</p>
          </div>
        </div>

        {/* Audio Status Indicator */}
        {!isLoading && (
          <div className="fixed bottom-8 right-8 flex items-center space-x-2 bg-shadow border border-eerie-dark rounded-lg px-4 py-2">
            <div className="w-3 h-3 bg-blood rounded-full animate-pulse"></div>
            <span className="text-eerie text-sm font-tech">LIVE</span>
          </div>
        )}
      </div>
    </div>
  );
}