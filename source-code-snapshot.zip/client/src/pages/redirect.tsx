import { useState, useEffect } from "react";
import { GlitchText } from "@/components/glitch-text";

export default function Redirect() {
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [currentMessage, setCurrentMessage] = useState(0);

  const messages = [
    "SIGNAL INTERCEPTED...",
    "REROUTING",
    "LOADING FINAL RESONANCE ANCHOR..."
  ];

  useEffect(() => {
    // Progress animation
    const progressInterval = setInterval(() => {
      setLoadingProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          // Redirect to Cyberwave Studios Lab after completion
          setTimeout(() => {
            window.location.href = "https://cyberwavestudios.com/lab.html";
          }, 1000);
          return 100;
        }
        return prev + 2;
      });
    }, 100);

    // Message cycling
    const messageInterval = setInterval(() => {
      setCurrentMessage(prev => (prev + 1) % messages.length);
    }, 2000);

    return () => {
      clearInterval(progressInterval);
      clearInterval(messageInterval);
    };
  }, []);

  return (
    <div className="min-h-screen relative overflow-hidden bg-void flex items-center justify-center">
      {/* Static Background Pattern */}
      <div className="fixed inset-0 static-bg"></div>
      
      {/* Scanlines Effect */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="w-full h-full opacity-20" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255, 255, 255, 0.1) 2px, rgba(255, 255, 255, 0.1) 4px)',
        }}></div>
      </div>

      <div className="text-center max-w-lg mx-auto px-4 relative z-10">
        
        {/* Infinity Symbol */}
        <div className="mb-12">
          <div className="relative inline-block">
            <svg 
              width="200" 
              height="100" 
              viewBox="0 0 200 100" 
              className="text-white opacity-90"
              data-testid="infinity-symbol"
            >
              <path 
                d="M50 50 C25 25, 25 75, 50 50 C75 25, 125 25, 150 50 C175 75, 175 25, 150 50 C125 75, 75 75, 50 50 Z" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="4"
                className="animate-pulse"
              />
            </svg>
          </div>
        </div>

        {/* Main Message */}
        <h1 className="text-3xl md:text-4xl font-tech font-black text-white mb-6">
          <GlitchText dataText={messages[currentMessage]}>
            {messages[currentMessage]}
          </GlitchText>
        </h1>
        
        {/* Progress Bar */}
        <div className="w-full max-w-md mx-auto bg-shadow border border-gray-600 rounded-full h-4 mb-6 overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-blood to-eerie transition-all duration-200 ease-out"
            style={{ width: `${loadingProgress}%` }}
          ></div>
        </div>

        {/* Progress Percentage */}
        <p className="text-gray-400 text-lg font-tech font-bold mb-8">
          {Math.round(loadingProgress)}%
        </p>

        {/* Status Text */}
        <div className="text-sm text-gray-500 font-mono tracking-wide space-y-1">
          <p>ESTABLISHING QUANTUM BRIDGE...</p>
          <p>SYNCHRONIZING TEMPORAL MATRICES...</p>
          <p className="text-blood">REDIRECTING TO CYBERWAVE STUDIOS</p>
        </div>
      </div>
    </div>
  );
}