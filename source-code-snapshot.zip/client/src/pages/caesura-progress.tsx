import { useState } from "react";
import { useLocation } from "wouter";
import { GlitchText } from "@/components/glitch-text";
import { useCountdown } from "@/contexts/CountdownContext";

// Uploaded videos are preserved alongside the self-hosted static build.
const video1 = "/videos/video1.mp4";
const video2 = "/videos/video2.mp4";

export default function CaesuraProgress() {
  const [, setLocation] = useLocation();
  const { isCountdownFinished } = useCountdown();
  const [currentVideo, setCurrentVideo] = useState<string | null>(null);
  const [videoPlaying, setVideoPlaying] = useState(false);

  const handleBackToMain = () => {
    setLocation('/main');
  };

  const handleVideo1Click = () => {
    console.log('Video 1: Detainment of All Cyberwaves clicked');
    setCurrentVideo(null); // Reset first
    setTimeout(() => {
      setCurrentVideo(video1);
      setVideoPlaying(true);
    }, 100);
  };

  const handleVideo2Click = () => {
    if (isCountdownFinished) {
      console.log('Video 2: Eradication of All Cyberwaves clicked');
      setCurrentVideo(null); // Reset first
      setTimeout(() => {
        setCurrentVideo(video2);
        setVideoPlaying(true);
      }, 100);
    }
  };

  const handleCloseVideo = () => {
    setCurrentVideo(null);
    setVideoPlaying(false);
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-void">
      {/* Static Background Pattern */}
      <div className="fixed inset-0 static-bg"></div>
      
      {/* Scanlines Effect */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="w-full h-full opacity-20" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 255, 65, 0.1) 2px, rgba(0, 255, 65, 0.1) 4px)',
        }}></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col px-4 py-8">
        
        {/* Header */}
        <header className="text-center mb-8 relative">
          <button 
            onClick={handleBackToMain}
            className="absolute top-0 left-0 z-50 bg-transparent hover:bg-eerie-dark border border-eerie px-4 py-2 rounded-lg font-tech font-bold text-eerie transition-all duration-300"
            data-testid="button-back-to-main"
          >
            ← RETURN TO MAIN
          </button>
          
          <h1 className="text-2xl md:text-4xl font-tech font-black text-blood mb-4 pt-14">
            <GlitchText dataText="CAESURA EVENT PROGRESS">CAESURA EVENT PROGRESS</GlitchText>
          </h1>
          <div className="text-gray-400 text-sm font-mono tracking-widest">
            CLASSIFIED OPERATIONS // SYNDICATE COMMAND
          </div>
          <div className="w-32 h-0.5 bg-gradient-to-r from-transparent via-blood to-transparent mx-auto mt-4"></div>
        </header>

        {/* Video Layout */}
        <main className="flex-1 flex items-center justify-center">
          <div className="max-w-6xl mx-auto">
            
            {/* Status Banner */}
            <div className="bg-shadow border border-blood-dark rounded-lg p-4 mb-8 text-center">
              <div className="text-blood text-sm font-tech font-bold tracking-widest mb-2">
                📡 OPERATION STATUS: {isCountdownFinished ? 'PHASE 2 ACTIVATED' : 'PHASE 1 ACTIVE'}
              </div>
              <div className="text-gray-400 text-xs font-mono">
                {isCountdownFinished ? 
                  'TEMPORAL INTERVENTION DETECTED // CYBERWAVE RESISTANCE ACTIVE' :
                  'TIMELINE SYNCHRONIZATION IN PROGRESS // AWAITING CAESURA INITIATION'
                }
              </div>
            </div>

            {/* Video Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Video 1 - Always Available */}
              <div className="relative group">
                <div className="bg-shadow border-2 border-blood rounded-lg overflow-hidden relative">
                  {/* Video Placeholder */}
                  <div 
                    className="aspect-video bg-void flex items-center justify-center cursor-pointer hover:bg-blood/10 transition-all duration-300"
                    onClick={handleVideo1Click}
                    data-testid="video-1-container"
                  >
                    <div className="text-center">
                      <div className="text-4xl mb-4">🎥</div>
                      <div className="text-blood text-lg font-tech font-bold mb-2">
                        PHASE 1: ACTIVE
                      </div>
                      <div className="text-gray-300 text-sm font-mono">
                        Click to view transmission
                      </div>
                    </div>
                  </div>
                  
                  {/* Video Info */}
                  <div className="p-4 border-t border-blood-dark">
                    <h3 className="text-eerie text-lg font-tech font-bold mb-2">
                      DETAINMENT OF ALL CYBERWAVES
                    </h3>
                    <p className="text-gray-400 text-sm leading-relaxed">
                      Syndicate seizure of all digital platforms across infinite timelines. 
                      Initial phase of Caesura Event protocol.
                    </p>
                  </div>
                </div>
              </div>

              {/* Video 2 - Available Only After Countdown */}
              <div className="relative group">
                <div className={`bg-shadow border-2 rounded-lg overflow-hidden relative transition-all duration-500 ${
                  isCountdownFinished ? 'border-eerie' : 'border-gray-600 opacity-50'
                }`}>
                  {/* Video Placeholder */}
                  <div 
                    className={`aspect-video bg-void flex items-center justify-center transition-all duration-300 ${
                      isCountdownFinished ? 'cursor-pointer hover:bg-eerie/10' : 'cursor-not-allowed'
                    }`}
                    onClick={handleVideo2Click}
                    data-testid="video-2-container"
                  >
                    <div className="text-center">
                      <div className="text-4xl mb-4">
                        {isCountdownFinished ? '🎥' : '🔒'}
                      </div>
                      <div className={`text-lg font-tech font-bold mb-2 ${
                        isCountdownFinished ? 'text-eerie' : 'text-gray-500'
                      }`}>
                        PHASE 2: {isCountdownFinished ? 'ACTIVATED' : 'LOCKED'}
                      </div>
                      <div className="text-gray-400 text-sm font-mono">
                        {isCountdownFinished ? 
                          'Click to view transmission' : 
                          'Awaiting timeline convergence'
                        }
                      </div>
                    </div>
                  </div>
                  
                  {/* Video Info */}
                  <div className="p-4 border-t border-gray-600">
                    <h3 className={`text-lg font-tech font-bold mb-2 ${
                      isCountdownFinished ? 'text-eerie' : 'text-gray-500'
                    }`}>
                      {isCountdownFinished ? 
                        'CYBERWAVE RESISTANCE PROTOCOL' : 
                        'ERADICATION OF ALL CYBERWAVES'
                      }
                    </h3>
                    <p className="text-gray-400 text-sm leading-relaxed">
                      {isCountdownFinished ? 
                        'Emergency broadcast: Cyberwave forces successfully interrupt Caesura Event. Timeline preservation protocol activated.' :
                        'Final phase of Syndicate operation. Complete elimination of unauthorized creativity across all timelines.'
                      }
                    </p>
                  </div>

                  {/* Lock Overlay for Video 2 when countdown not finished */}
                  {!isCountdownFinished && (
                    <div className="absolute inset-0 bg-void/80 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-6xl text-gray-500 mb-4">🔐</div>
                        <div className="text-gray-400 text-lg font-tech font-bold">
                          TEMPORAL LOCK ACTIVE
                        </div>
                        <div className="text-gray-500 text-sm font-mono mt-2">
                          Access denied until timeline convergence
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Instructions */}
            <div className="mt-8 text-center">
              <div className="bg-shadow border border-eerie-dark rounded-lg p-4 max-w-2xl mx-auto">
                <div className="text-eerie text-sm font-tech font-bold mb-2">
                  📋 OPERATION BRIEFING
                </div>
                <p className="text-gray-400 text-sm leading-relaxed">
                  {isCountdownFinished ? 
                    'Both phases are now accessible. The timeline has been secured. Review both transmissions to understand the complete operation.' :
                    'Phase 1 is currently active. Phase 2 will be unlocked upon timeline convergence completion.'
                  }
                </p>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Video Modal Overlay */}
      {videoPlaying && currentVideo && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="relative w-full max-w-6xl">
            {/* Close Button */}
            <button
              onClick={handleCloseVideo}
              className="absolute top-4 right-4 z-10 bg-blood hover:bg-blood-light text-white px-4 py-2 rounded-lg font-tech font-bold transition-all duration-300"
              data-testid="button-close-video"
            >
              ✕ CLOSE
            </button>

            {/* Video Container */}
            <div className="bg-shadow border-2 border-blood rounded-lg overflow-hidden">
              <video
                key={currentVideo}
                controls
                playsInline
                preload="auto"
                className="w-full max-h-[80vh] object-contain"
                data-testid="video-player"
                onEnded={() => setVideoPlaying(false)}
                onLoadedMetadata={(e) => {
                  console.log('Video metadata loaded');
                  const video = e.currentTarget;
                  console.log('Duration:', video.duration);
                  console.log('VideoWidth:', video.videoWidth);
                  console.log('VideoHeight:', video.videoHeight);
                }}
                onError={(e) => {
                  const video = e.currentTarget;
                  console.error('Video error event:', e);
                  console.error('Error code:', video.error?.code);
                  console.error('Error message:', video.error?.message);
                  console.error('Network state:', video.networkState);
                  console.error('Ready state:', video.readyState);
                  console.error('Current src:', video.currentSrc);
                }}
              >
                <source src={currentVideo} type="video/mp4" />
                <p className="text-white p-4">
                  Your browser does not support the video tag. 
                  <a href={currentVideo} className="text-blood underline ml-2" download>
                    Download the video file instead.
                  </a>
                </p>
              </video>
              
              {/* Video Info Bar */}
              <div className="bg-void border-t border-blood-dark p-4">
                <div className="flex items-center justify-between">
                  <div className="text-eerie font-tech font-bold">
                    🎥 CLASSIFIED TRANSMISSION ACTIVE
                  </div>
                  <div className="text-gray-400 text-sm font-mono">
                    SECURITY LEVEL: OMEGA-7
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
