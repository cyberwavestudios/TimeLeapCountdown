import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { GlitchText } from "@/components/glitch-text";
import { CountdownTimer } from "@/components/countdown-timer";
import { ParticleSystem } from "@/components/particle-system";
import { useAudio } from "@/hooks/useAudio";
import { useCountdown } from "@/contexts/CountdownContext";
import audioFile from "@assets/Invasion of All Worlds (Remix).mp3";

export default function Home() {
  const [, setLocation] = useLocation();
  const [currentTime, setCurrentTime] = useState("");
  const [showVersion, setShowVersion] = useState(false);
  const { isCountdownFinished } = useCountdown();
  const { play, isLoading: audioLoading, audioRef } = useAudio(audioFile, {
    loop: true,
    volume: 0.4,
    autoplay: false
  });

  useEffect(() => {
    const updateCurrentTime = () => {
      const now = new Date();
      const timeString = now.toLocaleTimeString('en-US', { 
        hour12: false,
        timeZone: 'UTC'
      }) + ' UTC';
      setCurrentTime(timeString);
    };

    updateCurrentTime();
    const interval = setInterval(updateCurrentTime, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Start audio when it's loaded, but only during Phase 1 (countdown active)
    if (!audioLoading && !isCountdownFinished) {
      const timer = setTimeout(() => {
        play();
      }, 100);
      return () => clearTimeout(timer);
    }
    
    // Pause audio when Phase 2 begins
    if (isCountdownFinished && audioRef.current) {
      audioRef.current.pause();
    }
  }, [audioLoading, play, isCountdownFinished, audioRef]);

  useEffect(() => {
    // Random glitch effects
    const glitchInterval = setInterval(() => {
      const glitchElements = document.querySelectorAll('.glitch-text');
      glitchElements.forEach(element => {
        if (Math.random() < 0.1) { // 10% chance every interval
          const htmlElement = element as HTMLElement;
          htmlElement.style.animation = 'none';
          setTimeout(() => {
            htmlElement.style.animation = '';
          }, 100);
        }
      });
    }, 2000);

    return () => clearInterval(glitchInterval);
  }, []);

  const handlePrepareForJump = () => {
    console.log('Prepare for Timeline Jump clicked');
    setLocation('/redirect');
  };

  const handleClassifiedFiles = () => {
    console.log('Classified Files clicked');
    setLocation('/classified');
  };

  const handleCaesuraProgress = () => {
    console.log('Caesura Event Progress clicked');
    setLocation('/caesura-progress');
  };

  const handleCountdownFinish = (isFinished: boolean) => {
    // Countdown state is now managed by the context
    console.log('Countdown finished:', isFinished);
  };

  return (
    <div className="min-h-screen relative overflow-x-hidden">
      {/* Static Background Pattern */}
      <div className="fixed inset-0 static-bg"></div>
      
      {/* Particle System Background */}
      <ParticleSystem />

      {/* Main Container */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header Section */}
        <header className="pt-8 pb-4 px-4 text-center">
          <div className="scanline">
            <h1 className="eerie-glow text-2xl md:text-4xl font-tech font-black text-eerie mb-2">
              <GlitchText dataText={isCountdownFinished ? "TIMELINE JUMP INTERRUPTED" : "TIMELINE JUMP"}>
                {isCountdownFinished ? "TIMELINE JUMP INTERRUPTED" : "TIMELINE JUMP"}
              </GlitchText>
            </h1>
          </div>
          <p className="text-gray-300 text-sm md:text-base font-mono tracking-widest">
            {isCountdownFinished ? 
              "INTERVENTION SUCCESSFUL // CYBERWAVE RESISTANCE" : 
              "CLASSIFIED PROJECT // ACCESS LEVEL: OMEGA"
            }
          </p>
          <div className="w-24 h-0.5 bg-gradient-to-r from-transparent via-blood to-transparent mx-auto mt-4"></div>
        </header>

        {/* Countdown Section */}
        <main className="flex-1 flex items-center justify-center px-4">
          <div className="text-center max-w-4xl mx-auto">
            <div className="mb-8">
              <h2 className="text-lg md:text-2xl font-tech text-blood-light mb-6 tracking-wider">
                <GlitchText dataText={isCountdownFinished ? "OPERATION COMPLETED" : "INITIATION IN"}>
                  {isCountdownFinished ? "OPERATION COMPLETED" : "INITIATION IN"}
                </GlitchText>
              </h2>
              
              {/* Countdown Timer Display */}
              <CountdownTimer onCountdownFinish={handleCountdownFinish} />
            </div>

            {/* Caesura Event Progress Button */}
            <div className="mb-8">
              <button 
                className="bg-eerie-dark hover:bg-eerie border border-eerie px-6 py-3 rounded-lg font-tech font-bold tracking-wider text-eerie transition-all duration-300 hover:shadow-lg hover:shadow-eerie/30 mb-2"
                onClick={handleCaesuraProgress}
                data-testid="button-caesura-progress"
              >
                🔓 CAESURA EVENT PROGRESS
              </button>
              <div className="text-xs text-gray-500 font-mono tracking-wide">
                ACCESS SYNDICATE OPERATIONS STATUS
              </div>
            </div>

            {/* Warning Message */}
            <div className="bg-shadow border border-eerie-dark rounded-lg p-6 mb-8 relative overflow-hidden">
              <div className="scanline"></div>
              <div className="relative z-10">
                <h3 className="text-eerie text-lg md:text-xl font-tech font-bold mb-3 tracking-wide">
                  ⚠ TEMPORAL ANOMALY DETECTED
                </h3>
                <p className="text-gray-300 text-sm md:text-base leading-relaxed mb-4">
                  Critical timeline convergence approaching. All personnel must report to designated 
                  coordinates before temporal displacement event initiates. Failure to comply may 
                  result in permanent timeline displacement.
                </p>
                <div className="text-xs text-blood-light font-mono tracking-widest">
                  STATUS: ACTIVE // CLEARANCE: OMEGA-7 // PROTOCOL: BLACKOUT
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {!isCountdownFinished ? (
                <>
                  <button 
                    className="bg-blood hover:bg-blood-light border border-blood-light px-8 py-3 rounded-lg font-tech font-bold tracking-wider transition-all duration-300 hover:shadow-lg hover:shadow-blood/50 glitch"
                    onClick={handlePrepareForJump}
                    data-testid="button-prepare-jump"
                  >
                    PREPARE FOR JUMP
                  </button>
                  <button 
                    className="bg-transparent hover:bg-eerie-dark border border-eerie px-8 py-3 rounded-lg font-tech font-bold tracking-wider text-eerie transition-all duration-300 hover:shadow-lg hover:shadow-eerie/30"
                    onClick={handleClassifiedFiles}
                    data-testid="button-classified-files"
                  >
                    CLASSIFIED FILES
                  </button>
                </>
              ) : (
                <>
                  <button 
                    className="bg-transparent hover:bg-eerie-dark border border-eerie px-8 py-3 rounded-lg font-tech font-bold tracking-wider text-eerie transition-all duration-300 hover:shadow-lg hover:shadow-eerie/30"
                    onClick={handleClassifiedFiles}
                    data-testid="button-classified-files"
                  >
                    CLASSIFIED FILES
                  </button>
                  <button 
                    className="bg-blood hover:bg-blood-light border border-blood-light px-8 py-3 rounded-lg font-tech font-bold tracking-wider transition-all duration-300 hover:shadow-lg hover:shadow-blood/50 glitch"
                    onClick={() => setLocation('/continuum')}
                    data-testid="button-syndicate-return"
                  >
                    ⚔️ SYNDICATE WILL RETURN...
                  </button>
                </>
              )}
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="py-6 px-4 text-center border-t border-shadow">
          <div className="text-xs text-gray-500 font-mono tracking-widest space-y-2">
            <p>PROJECT TIMELINE JUMP // DEPARTMENT OF TEMPORAL SCIENCES</p>
            <p className="text-blood">[ UNAUTHORIZED ACCESS IS PROHIBITED ]</p>
            <p>
              COORDINATES: CLASSIFIED // TIME: <span data-testid="current-time">{currentTime}</span>
            </p>
            <button 
              onClick={() => setShowVersion(!showVersion)}
              className="mt-2 text-xs text-gray-600 hover:text-eerie transition-colors"
              data-testid="button-show-version"
            >
              {showVersion ? '▼' : '▶'} SYSTEM VERSION
            </button>
            {showVersion && (
              <div className="mt-2 p-3 bg-shadow border border-eerie-dark rounded text-left max-w-md mx-auto">
                <div className="text-eerie font-bold mb-2">DEPLOYMENT INFO:</div>
                <div className="space-y-1 text-gray-400">
                  <p>Version: <span className="text-eerie">Self-hosted static edition</span></p>
                  <p>Videos: <span className="text-eerie">/videos/</span></p>
                </div>
              </div>
            )}
          </div>
        </footer>
      </div>
    </div>
  );
}
