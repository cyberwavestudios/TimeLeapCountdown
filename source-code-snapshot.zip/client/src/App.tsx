import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CountdownProvider } from "@/contexts/CountdownContext";
import Home from "@/pages/home";
import Auth from "@/pages/auth";
import Classified from "@/pages/classified";
import Redirect from "@/pages/redirect";
import CaesuraProgress from "@/pages/caesura-progress";
import Continuum from "@/pages/continuum";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Auth} />
      <Route path="/main" component={Home} />
      <Route path="/classified" component={Classified} />
      <Route path="/redirect" component={Redirect} />
      <Route path="/caesura-progress" component={CaesuraProgress} />
      <Route path="/continuum" component={Continuum} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <CountdownProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </CountdownProvider>
    </QueryClientProvider>
  );
}

export default App;
