import { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';

interface CountdownContextType {
  isCountdownFinished: boolean;
  setCountdownFinished: (finished: boolean) => void;
  targetDate: Date;
}

const CountdownContext = createContext<CountdownContextType | undefined>(undefined);

interface CountdownProviderProps {
  children: ReactNode;
}

export function CountdownProvider({ children }: CountdownProviderProps) {
  // Global countdown target date - Timeline Jump Event
  const [targetDate] = useState(() => {
    // Timeline Jump Event: November 20, 2025 at 7:00 PM Central Standard Time
    // Central Standard Time (CST) = UTC-6, so 7:00 PM CST = 1:00 AM UTC next day
    const timelineJumpDate = new Date('2025-11-21T01:00:00Z'); // Nov 20, 7PM Central = Nov 21, 1AM UTC
    return timelineJumpDate;
  });

  // Memoize the override flag so we can track changes
  const forceFinished = useMemo(() => {
    return import.meta.env.VITE_FORCE_COUNTDOWN_FINISHED === 'true';
  }, []);

  const [isCountdownFinished, setIsCountdownFinished] = useState(() => {
    // Developer override: Force countdown finished state for testing/emergency
    if (forceFinished) {
      return true;
    }
    
    // Check if the global countdown has finished based on current time
    const now = new Date().getTime();
    const timeRemaining = targetDate.getTime() - now;
    return timeRemaining <= 0;
  });

  const setCountdownFinished = (finished: boolean) => {
    setIsCountdownFinished(finished);
    // No localStorage needed - this is a global event countdown
  };

  useEffect(() => {
    // Developer override: Force finished state and skip countdown ticker
    if (forceFinished) {
      if (!isCountdownFinished) {
        setIsCountdownFinished(true);
      }
      return;
    }
    
    // Normal countdown logic: reset to false if flag was removed and time remaining
    const now = new Date().getTime();
    const timeRemaining = targetDate.getTime() - now;
    
    if (timeRemaining > 0 && isCountdownFinished) {
      // Reset state if countdown is no longer finished (flag was removed)
      setIsCountdownFinished(false);
    }
    
    // Global countdown ticker - ensures real-time unlock across all pages
    const checkCountdown = () => {
      const now = new Date().getTime();
      const timeRemaining = targetDate.getTime() - now;
      
      if (timeRemaining <= 0 && !isCountdownFinished) {
        setIsCountdownFinished(true);
      }
    };

    // Check immediately and then every second
    checkCountdown();
    const interval = setInterval(checkCountdown, 1000);

    return () => clearInterval(interval);
  }, [targetDate, isCountdownFinished, forceFinished]);

  return (
    <CountdownContext.Provider value={{
      isCountdownFinished,
      setCountdownFinished,
      targetDate
    }}>
      {children}
    </CountdownContext.Provider>
  );
}

export function useCountdown() {
  const context = useContext(CountdownContext);
  if (context === undefined) {
    throw new Error('useCountdown must be used within a CountdownProvider');
  }
  return context;
}