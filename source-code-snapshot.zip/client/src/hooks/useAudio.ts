import { useEffect, useRef, useState } from 'react';

interface UseAudioOptions {
  loop?: boolean;
  volume?: number;
  autoplay?: boolean;
}

export function useAudio(src: string, options: UseAudioOptions = {}) {
  const { loop = true, volume = 0.5, autoplay = false } = options;
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const audio = new Audio(src);
    audio.loop = loop;
    audio.volume = volume;
    audio.preload = 'auto';

    const handleCanPlayThrough = () => {
      setIsLoading(false);
    };

    const handlePlay = () => {
      setIsPlaying(true);
    };

    const handlePause = () => {
      setIsPlaying(false);
    };

    audio.addEventListener('canplaythrough', handleCanPlayThrough);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);

    audioRef.current = audio;

    return () => {
      audio.removeEventListener('canplaythrough', handleCanPlayThrough);
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.pause();
      audio.src = '';
    };
  }, [src, loop, volume]);

  const play = async () => {
    if (audioRef.current && !isLoading) {
      try {
        await audioRef.current.play();
      } catch (error) {
        console.warn('Audio play failed:', error);
      }
    }
  };

  const pause = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
  };

  return {
    isPlaying,
    isLoading,
    play,
    pause,
    audioRef
  };
}