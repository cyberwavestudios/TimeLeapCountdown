import { useEffect, useRef } from "react";

interface Particle {
  x: number;
  y: number;
  size: number;
  color: string;
  opacity: number;
  animationDelay: number;
  animationDuration: number;
}

export function ParticleSystem() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    const particleCount = window.innerWidth > 768 ? 50 : 25;
    const colors = ['#00FF41', '#FF0000', '#8B0000', '#10B981'];

    // Clear existing particles
    container.innerHTML = '';

    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      
      const size = Math.random() * 3 + 1;
      const color = colors[Math.floor(Math.random() * colors.length)];
      const opacity = Math.random() * 0.7 + 0.1;
      const animationDelay = Math.random() * 3;
      const animationDuration = Math.random() * 3 + 2;
      
      particle.style.width = `${size}px`;
      particle.style.height = `${size}px`;
      particle.style.left = `${Math.random() * 100}%`;
      particle.style.top = `${Math.random() * 100}%`;
      particle.style.background = color;
      particle.style.opacity = opacity.toString();
      particle.style.animationDelay = `${animationDelay}s`;
      particle.style.animationDuration = `${animationDuration}s`;
      
      container.appendChild(particle);
    }

    const handleResize = () => {
      // Recreate particles on resize
      container.innerHTML = '';
      const newParticleCount = window.innerWidth > 768 ? 50 : 25;
      
      for (let i = 0; i < newParticleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        
        const size = Math.random() * 3 + 1;
        const color = colors[Math.floor(Math.random() * colors.length)];
        const opacity = Math.random() * 0.7 + 0.1;
        const animationDelay = Math.random() * 3;
        const animationDuration = Math.random() * 3 + 2;
        
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 100}%`;
        particle.style.background = color;
        particle.style.opacity = opacity.toString();
        particle.style.animationDelay = `${animationDelay}s`;
        particle.style.animationDuration = `${animationDuration}s`;
        
        container.appendChild(particle);
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 pointer-events-none z-0"
      data-testid="particle-system"
    />
  );
}
