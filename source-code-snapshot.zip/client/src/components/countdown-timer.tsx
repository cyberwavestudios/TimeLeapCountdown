import { useState, useEffect } from "react";
import { useCountdown } from "@/contexts/CountdownContext";

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

interface CountdownTimerProps {
  onCountdownFinish?: (isFinished: boolean) => void;
}

export function CountdownTimer({ onCountdownFinish }: CountdownTimerProps) {
  const { targetDate, isCountdownFinished, setCountdownFinished } = useCountdown();
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 10, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {

    const updateCountdown = () => {
      const now = new Date().getTime();
      const timeRemaining = targetDate.getTime() - now;

      if (timeRemaining <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        if (!isCountdownFinished) {
          setCountdownFinished(true);
          onCountdownFinish?.(true);
        }
        return;
      }

      const days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
      const hours = Math.floor((timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, [targetDate, isCountdownFinished, setCountdownFinished, onCountdownFinish]);

  const formatTime = (time: number): string => {
    return time.toString().padStart(2, '0');
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 mb-8">
      {/* Days */}
      <div className="countdown-glow bg-void border-2 border-blood rounded-lg p-4 md:p-8 relative group">
        <div 
          className="text-3xl md:text-6xl font-tech font-black text-white mb-2"
          data-testid="countdown-days"
        >
          {formatTime(timeLeft.days)}
        </div>
        <div className="text-xs md:text-sm text-gray-400 font-mono tracking-widest">DAYS</div>
        <div className="absolute inset-0 bg-blood opacity-0 group-hover:opacity-10 transition-opacity rounded-lg"></div>
      </div>
      
      {/* Hours */}
      <div className="countdown-glow bg-void border-2 border-blood rounded-lg p-4 md:p-8 relative group">
        <div 
          className="text-3xl md:text-6xl font-tech font-black text-white mb-2"
          data-testid="countdown-hours"
        >
          {formatTime(timeLeft.hours)}
        </div>
        <div className="text-xs md:text-sm text-gray-400 font-mono tracking-widest">HOURS</div>
        <div className="absolute inset-0 bg-blood opacity-0 group-hover:opacity-10 transition-opacity rounded-lg"></div>
      </div>
      
      {/* Minutes */}
      <div className="countdown-glow bg-void border-2 border-blood rounded-lg p-4 md:p-8 relative group">
        <div 
          className="text-3xl md:text-6xl font-tech font-black text-white mb-2"
          data-testid="countdown-minutes"
        >
          {formatTime(timeLeft.minutes)}
        </div>
        <div className="text-xs md:text-sm text-gray-400 font-mono tracking-widest">MINS</div>
        <div className="absolute inset-0 bg-blood opacity-0 group-hover:opacity-10 transition-opacity rounded-lg"></div>
      </div>
      
      {/* Seconds */}
      <div className="countdown-glow bg-void border-2 border-blood rounded-lg p-4 md:p-8 relative group">
        <div 
          className="text-3xl md:text-6xl font-tech font-black text-white mb-2"
          data-testid="countdown-seconds"
        >
          {formatTime(timeLeft.seconds)}
        </div>
        <div className="text-xs md:text-sm text-gray-400 font-mono tracking-widest">SECS</div>
        <div className="absolute inset-0 bg-blood opacity-0 group-hover:opacity-10 transition-opacity rounded-lg"></div>
      </div>
    </div>
  );
}
